import json

def lambda_handler(event, context):
    print("Event:", json.dumps(event))

    token = event.get('authorizationToken')  
    method_arn = event.get('methodArn')

    print(f"Token received: {token}")
    print(f"Method ARN: {method_arn}")

    expected_token = 'expecting-token'

    if token == expected_token:
        effect = 'Allow'
    else:
        effect = 'Deny'

    return generate_policy('user', effect, method_arn)

def generate_policy(principal_id, effect, resource):
    if not resource:
        return {
            'principalId': principal_id,
            'policyDocument': {
                'Version': '2012-10-17',
                'Statement': [{
                    'Action': 'execute-api:Invoke',
                    'Effect': 'Deny',
                    'Resource': '*'
                }]
            }
        }

    policy_document = {
        'Version': '2012-10-17',
        'Statement': [{
            'Action': 'execute-api:Invoke',
            'Effect': effect,
            'Resource': resource
        }]
    }

    return {
        'principalId': principal_id,
        'policyDocument': policy_document
    }
